﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IngredientsICETASK1
{
    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Steps { get; set; } = new List<string>();

        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories);
        }
    }

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    class Program
    {
        static List<Recipe> recipes = new List<Recipe>();

        static void Main()
        {
            while (true)
            {
                Console.WriteLine("\nRecipe Manager");
                Console.WriteLine("1. Add a new recipe");
                Console.WriteLine("2. View recipes");
                Console.WriteLine("3. Exit");
                Console.Write("Choose an option: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        AddRecipe();
                        break;
                    case "2":
                        ViewRecipes();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }

        static void AddRecipe()
        {
            Recipe recipe = new Recipe();

            Console.Write("Enter the recipe name: ");
            recipe.Name = Console.ReadLine();

            Console.Write("Enter the number of ingredients: ");
            if (!int.TryParse(Console.ReadLine(), out int numIngredients) || numIngredients <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
                return;
            }

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"\nIngredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                if (!double.TryParse(Console.ReadLine(), out double quantity) || quantity <= 0)
                {
                    Console.WriteLine("Invalid quantity. Skipping ingredient.");
                    continue;
                }
                Console.Write("Unit: ");
                string unit = Console.ReadLine();
                Console.Write("Calories: ");
                if (!double.TryParse(Console.ReadLine(), out double calories) || calories < 0)
                {
                    Console.WriteLine("Invalid calorie value. Skipping ingredient.");
                    continue;
                }
                Console.Write("Food Group: ");
                string foodGroup = Console.ReadLine();

                recipe.Ingredients.Add(new Ingredient
                {
                    Name = name,
                    Quantity = quantity,
                    Unit = unit,
                    Calories = calories,
                    FoodGroup = foodGroup
                });
            }

            Console.Write("Enter the number of steps: ");
            if (!int.TryParse(Console.ReadLine(), out int numSteps) || numSteps <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
                return;
            }

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Step {i + 1}: ");
                recipe.Steps.Add(Console.ReadLine());
            }

            recipes.Add(recipe);
            Console.WriteLine($"Recipe '{recipe.Name}' added successfully!");
        }

        static void ViewRecipes()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes available.");
                return;
            }

            // Sort recipes alphabetically by name
            recipes = recipes.OrderBy(r => r.Name).ToList();

            Console.WriteLine("\nAvailable Recipes:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            Console.Write("Enter the number of the recipe to view: ");
            if (!int.TryParse(Console.ReadLine(), out int choice) || choice < 1 || choice > recipes.Count)
            {
                Console.WriteLine("Invalid selection.");
                return;
            }

            DisplayRecipe(recipes[choice - 1]);
        }

        static void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine($"\nRecipe: {recipe.Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
            }

            double totalCalories = recipe.CalculateTotalCalories();
            Console.WriteLine($"\nTotal Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: This recipe exceeds 300 calories!");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipe.Steps[i]}");
            }
        }

        

        }
}